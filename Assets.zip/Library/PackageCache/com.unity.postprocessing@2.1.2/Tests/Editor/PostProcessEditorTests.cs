﻿using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;
using UnityEngine.TestTools;
using UnityEditor;

class PostProcessEditorTests
{
    [Test]
    public void DummyTest()
    {
        Assert.IsTrue(true);
    }
}
