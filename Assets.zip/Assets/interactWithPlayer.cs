﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class interactWithPlayer : MonoBehaviour
{

    private Collider2D collider;
    // Start is called before the first frame update
    void Start()
    {   
       //collider = getComp
       
    }

    // Update is called once per frame
    void Update()
    {

        //this.
    }

    private void OnTriggerEnter(Collider other)
    {
        //Debug.log()
    }
}   

